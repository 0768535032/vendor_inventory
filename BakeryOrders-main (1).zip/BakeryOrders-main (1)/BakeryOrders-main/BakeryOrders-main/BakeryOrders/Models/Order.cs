using System;
using System.Collections.Generic;

namespace BakeryOrders.Models
{
    public class Order
    {
        public string Title { get; set; }
        public int BreadQuantity { get; set; }
        public int PastryQuantity { get; set; }
        public string Description { get; set; }
        public string Date { get; set; }
        public double Price { get; private set; }
        private static List<Order> _instances = new List<Order> {};
        public int Id { get; }

        public Order(string title, int breadQuantity, int pastryQuantity, string description, string date)
        {
            Title = title;
            BreadQuantity = breadQuantity;
            PastryQuantity = pastryQuantity;
            Description = description;
            Date = date;
            _instances.Add(this);
            Id = _instances.Count;
        }

        public static List<Order> GetAll()
        {
            return _instances;
        }

        public static void ClearAll()
        {
            _instances.Clear();
        }

        public static Order Find(int searchId)
        {
            if (searchId <= 0 || searchId > _instances.Count)
            {
                return null; // Return null if the id is out of range
            }
            return _instances[searchId - 1];
        }

        public void CalculatePrice()
        {
            Price = BreadQuantity * 2.5 + PastryQuantity * 3.5;
        }
    }
}
