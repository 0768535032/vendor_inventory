using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using BakeryOrders.Models;

namespace BakeryOrders.Controllers
{
    public class OrdersController : Controller
    {
        [HttpGet("/vendors/{vendorId}/orders/new")]
        public ActionResult New(int vendorId)
        {
            Vendor vendor = Vendor.Find(vendorId);
            if (vendor == null)
            {
                return NotFound(); // Return a 404 Not Found if the vendor does not exist
            }
            ViewData["VendorId"] = vendorId;
            return View(vendor);
        }

        [HttpPost("/vendors/{vendorId}/orders")]
        public ActionResult Create(int vendorId, int bread1, int bread2, int bread3, int pastry1, int pastry2, int pastry3, string orderDescription, DateTime orderDate)
        {
            Vendor vendor = Vendor.Find(vendorId);
            if (vendor == null)
            {
                return NotFound();
            }
            string vendorName = vendor.Name;
            int breadOrder = bread1 + bread2 + bread3;
            int pastryOrder = pastry1 + pastry2 + pastry3;
            string orderDateOnly = orderDate.ToShortDateString();
            string orderTitle = vendorName + "-" + orderDateOnly;
            Order newOrder = new Order(orderTitle, breadOrder, pastryOrder, orderDescription, orderDateOnly);
            newOrder.CalculatePrice();
            vendor.AddOrder(newOrder);

            Dictionary<string, object> model = new Dictionary<string, object>
            {
                { "Orders", vendor.Orders },
                { "Vendor", vendor }
            };

            return View("Show", model);
        }

        [HttpPost("/orders/delete")]
        public ActionResult DeleteAll()
        {
            Order.ClearAll();
            return View();
        }

        [HttpGet("/vendors/{vendorId}/orders/{orderId}")]
        public ActionResult Show(int vendorId, int orderId)
        {
            Vendor vendor = Vendor.Find(vendorId);
            Order order = Order.Find(orderId);
            if (vendor == null || order == null)
            {
                return NotFound(); // Return a 404 Not Found if the vendor or order does not exist
            }

            Dictionary<string, object> model = new Dictionary<string, object>
            {
                { "order", order },
                { "vendor", vendor }
            };
            return View(model);
        }
    }
}
